#include "MenuItem.h"

MenuItem::MenuItem(string name, int price, int category) {
	_name = name;
	_price = price;
	_category = category;
}